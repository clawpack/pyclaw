for mq1=mq
  subplot(length(mq),1,find(mq==mq1))
  axis([-1 1 -1 1])
  end

